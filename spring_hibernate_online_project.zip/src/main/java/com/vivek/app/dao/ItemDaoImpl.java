package com.vivek.app.dao;

import com.vivek.app.model.Item;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class ItemDaoImpl implements ItemDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Transactional
    public void save(Item item) {
        sessionFactory.getCurrentSession().save(item);
    }

    @Transactional(readOnly = true)
    public Item get(int id) {
        return sessionFactory.getCurrentSession().get(Item.class, id);
    }

    @Transactional
    public void update(Item item) {
        sessionFactory.getCurrentSession().update(item);
    }

    @Transactional
    public void delete(int id) {
        Item item = get(id);
        if (item != null) sessionFactory.getCurrentSession().delete(item);
    }
}
