package com.vivek.app.dao;

import com.vivek.app.model.Item;

public interface ItemDao {
    void save(Item item);
    Item get(int id);
    void update(Item item);
    void delete(int id);
}
