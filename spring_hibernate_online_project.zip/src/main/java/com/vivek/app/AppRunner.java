package com.vivek.app;

import com.vivek.app.dao.ItemDao;
import com.vivek.app.model.Item;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AppRunner {
    public static void main(String[] args) {
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

        ItemDao itemDao = context.getBean(ItemDao.class);

        Item item = new Item();
        item.setName("Monitor");
        item.setQuantity(5);
        itemDao.save(item);

        Item fetched = itemDao.get(item.getId());
        System.out.println("Fetched: " + fetched.getName());

        context.close();
    }
}
